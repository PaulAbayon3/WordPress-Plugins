<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

/*
Plugin Name: WooCommerce Pinas Remittance Gateway
Plugin URI: https://github.com/PaulAbayon3/WordPress-Plugins/woocommerce-pinas-remittance-gateway/
Description: Adds Western Union, Cebuana Lhuillier, M Lhuillier, Palawan Express Gateway to WooCommerce e-commerce plugin
Version: 1.0.0
Author: Paul Abayon III
Author URI: https://paultech.me/
*/

// Include our Gateway Class and register Payment Gateway with WooCommerce
add_action( 'plugins_loaded', 'woo_pr_init', 0 );
function woo_pr_init() {
	// If the parent WC_Payment_Gateway class doesn't exist
	// it means WooCommerce is not installed on the site
	// so do nothing
	if ( ! class_exists( 'WC_Payment_Gateway' ) ) return;
	
	// If we made it this far, then include our Gateway Class
	include_once( 'pinas-remittances.php' );

	// Now that we have successfully included our class,
	// Lets add it too WooCommerce
	add_filter( 'woocommerce_payment_gateways', 'woo_add_pr_gateway' );
	function woo_add_pr_gateway( $methods ) {
		$methods[] = 'WC_Gateway_Pinas_Remittances';
		return $methods;
	}
}

// Add custom action links
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), 'spyr_authorizenet_aim_action_links_premit' );
function spyr_authorizenet_aim_action_links_premit( $links ) {
	$plugin_links = array(
		'<a href="' . admin_url( 'admin.php?page=wc-settings&tab=checkout&section=premit' ) . '">' . __( 'Settings', 'woocommerce' ) . '</a>',
	);

	// Merge our new link with the default ones
	return array_merge( $plugin_links, $links );	
}

?>