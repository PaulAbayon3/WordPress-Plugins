=== WooCommerce Pinas Remittance Gateway ===
Contributors:  Paul Abayon III
Tags: woocommerce gateway, gateway, western union, palawan express, cebuana lhuillier, m lhuillier, payment
Requires at least: 4.0.0
Tested up to: 5.2.2
Stable tag: 1.1.0
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

The plugin helps you accept payments using Western Union, Palawan Express, Cebuana Lhuillier, and M Lhuillier money remittances.

== Description ==

The plugin helps you accept payments using Western Union, Palawan Express, Cebuana Lhuillier, and M Lhuillier money remittances.

== Installation ==

1. Upload 'woocommerce-westerm-union-gateway' to the '/wp-content/plugins/' directory
2. Activate the plugin through the 'Plugins' menu in WordPress
3. Access 'admin.php?page=wc-settings&tab=checkout&section=premit' in order to change the description and the details provided in the email

== Changelog ==
= 1.0.0 =
* Confirmed compatibility with PHP 7.3
* Confirmed compatibility with WooCommerce 3.7.x
* Confirmed compatibility with WordPress 5.2.x
* Updated Plugin URI
* Added order status settings. You can now choose if you want the order to be set On Hold or Processing status.
* Removed the tooltip and displayed the intructions under each settings. This will help you better understand what each setting does.
* Updated the plugin description.
* Updated the Settings button to get you in the right WooCommerce section.
* The plugin now reduces the stock using the latest code sintax (provided by WooCommerce).
= 1.1.0 =
* Added & tested Cebuana Lhuillier payment gateway

Disclaimer: The version 1.1.0 is a minor release and it should not affect affect your database settings. However, please do a full site backup and test on a staging site before deploying to a live/production server.